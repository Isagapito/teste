package com.senai.cadastrojogos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadastrojogosApplicationTests {

	@Test
	void contextLoads() {
	}

}
