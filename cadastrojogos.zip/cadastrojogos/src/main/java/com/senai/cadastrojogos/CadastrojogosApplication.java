package com.senai.cadastrojogos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CadastrojogosApplication {

	public static void main(String[] args) {
		SpringApplication.run(CadastrojogosApplication.class, args);
	}

}
