package com.senai.cadastrojogos.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.senai.cadastrojogos.entities.CadastroJogos;


 public interface CadastroJogosRepository extends JpaRepository<CadastroJogos, Long > {

}
