package com.senai.cadastrojogos.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.senai.cadastrojogos.entities.CadastroJogos;
import com.senai.cadastrojogos.repositories.CadastroJogosRepository;

@Service
public class CadastroJogosService {
	
	@Autowired
	private CadastroJogosRepository objetoCadastroJogos ;
	 
	public CadastroJogos salvarCadastroJogos (CadastroJogos CadastroJogos) {
		return objetoCadastroJogos.save(CadastroJogos);
		
	} 
	
	public List<CadastroJogos> buscarTodoCadastroJogos(){
		return objetoCadastroJogos.findAll();
	}
}
