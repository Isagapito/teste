package com.senai.cadastrojogos.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_jogos")
public class CadastroJogos {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idJogo;
	
	@Column(name = "nome_jogo")
	private String nomeJogo;
	
	@Column(name = "ano_lançamento")
	private String anoLancamento;
	
	@Column(name = "tipo_jogo")
	private String tipoJogo;
	
	CadastroJogos(){
		
	}
	CadastroJogos(String nomeJogo, String anoLancamento, String tipoJogo){
		this.nomeJogo = nomeJogo;
		this.anoLancamento = anoLancamento;
		this.tipoJogo = tipoJogo;
	}
	public Long getIdJogo() {
		return idJogo;
	}
	public void setIdJogo(Long idJogo) {
		this.idJogo = idJogo;
	}
	public String getNomeJogo() {
		return nomeJogo;
	}
	public void setNomeJogo(String nomeJogo) {
		this.nomeJogo = nomeJogo;
	}
	public String getAnoLancamento() {
		return anoLancamento;
	}
	public void setAnoLancamento(String anoLancamento) {
		this.anoLancamento = anoLancamento;
	}
	public String getTipoJogo() {
		return tipoJogo;
	}
	public void setTipoJogo(String tipoJogo) {
		this.tipoJogo = tipoJogo;
	}
	
	
	

}
