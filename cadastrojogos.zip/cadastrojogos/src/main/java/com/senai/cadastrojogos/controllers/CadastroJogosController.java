package com.senai.cadastrojogos.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.senai.cadastrojogos.entities.CadastroJogos;
import com.senai.cadastrojogos.service.CadastroJogosService;

@RestController
@RequestMapping("/cadastrojogos")
public class CadastroJogosController {

	@Autowired
	private CadastroJogosService objetoCadastroJogosService;
	
	public CadastroJogos criarNovoCadastroJogo(@RequestBody CadastroJogos cadastroJogos) {
		return objetoCadastroJogosService.salvarCadastroJogos(cadastroJogos);
	}
	
	@GetMapping
	public List<CadastroJogos> buscarTodoCadastroJogos(){
		return objetoCadastroJogosService.buscarTodoCadastroJogos();
	}
	
	
}
