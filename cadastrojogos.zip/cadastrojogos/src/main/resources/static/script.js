// Quando clicar no botão "Cadastrar"
document.getElementById('formCadastro').addEventListener('submit', function(e) {
	e.preventDefault();

	const nomeConst = document.getElementById('nomeFormulario').value;
	const anoConst = document.getElementById('anoFormulario').value;
    const tipoConst = document.getElementById('tipoFormulario').value

	// Enviar para a API
	fetch('http://localhost:8080/cadastrojogos', {
		method: 'POST',
		headers: { 'Content-Type': 'application/json' },
		body: JSON.stringify(
			{ 
				nomeJogo: nomeConst, 
				anoLancamento: anoConst,
                tipoJogo: tipoConst
			})
	});

	document.getElementById('formCadastro').reset();
	location.reload();

});

// Quando a página carregar
window.onload = function() {
	
	fetch('http://localhost:8080/cadastropessoa')
		.then(res => res.json())
		.then(Jogos => {
			const tabela = document.getElementById('tabelaJogos').querySelector('tbody');
			Jogos.forEach(p => {
				const linha = tabela.insertRow();
				linha.insertCell(0).textContent = p.nomeJogo;
				linha.insertCell(1).textContent = p.anoLancamento;
                linha.insertCell(2).textContent = p.tipoJogo;
			});
		});
};